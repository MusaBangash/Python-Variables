# ML project starter

A ready-made structure for the Day 2 project: **train → save → predict → app**, for any of the 5 datasets.
The plumbing (loading, splitting, saving, validation, app) is done. **The ML decisions are yours**: which models, which features, which metric, which threshold, and what it all means.

## 1 · Set up (once)

```bash
# after unzipping:
cd ml-project-starter
git init && git add . && git commit -m "Starter project"
python -m venv .venv          # optional: a clean environment
source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Create an empty repository on GitHub and push to it (`git remote add origin <url>` then `git push -u origin main`).

## 2 · Choose your dataset

Copy your dataset's config to the project root:

```bash
cp datasets/titanic/config.json config.json        # or telco_churn, medical_charges, california_housing, adult_income
```

`config.json` says which column is the target, whether the task is classification or regression, which columns are IDs or should be dropped, how missing values are written (e.g. `"?"`), which columns are sensitive (for the fairness check), the main metric and the random seed.

## 3 · Run the pipeline

```bash
python train.py                                            # compares models with 5-fold CV, tests the best ONCE, saves it
python predict.py --input reports/new_rows_example.csv     # batch predictions on unseen rows
pytest -q                                                  # tests: the saved model predicts; bad input is rejected
streamlit run app.py                                       # the web app
```

Out of the box only a **baseline** model exists, so the first run gives baseline scores. That is intentional: your job starts here.

## 4 · Your TODOs (search the code for "TODO")

| Session | File | What to do |
|---|---|---|
| 2 | `src/models.py` → `get_candidates` | add at least **two real models** |
| 3 | `src/features.py` → `add_features` | add at least **one feature** you can justify with a hypothesis |
| 3 | `src/models.py` → `get_search_spaces` | add a search space; run `python train.py --tune` |
| 3 | `config.json` | for classification, choose and justify a `threshold` |
| 4 | `MODEL_CARD.md` | fill every section with your real numbers |
| 5 | `app.py` | improve the app: explain the prediction in plain words, show your charts |
| 5 | `README.md` (this file) | replace section 6 below with your project write-up |

Every run of `train.py` appends a line to `experiments.csv`: what you tried and what it scored. Commit after each meaningful experiment.

## 5 · What the files do

| File | Purpose |
|---|---|
| `config.json` | which dataset / target / metric / seed |
| `src/data.py` | load, split (fixed seed, stratified for classification), infer the input schema, validate new rows |
| `src/features.py` | feature engineering + preprocessing (impute, scale, one-hot) |
| `src/models.py` | candidate models and tuning spaces |
| `src/evaluate.py` | metrics, plots, per-group (fairness) report |
| `train.py` | the whole training run; saves `models/` and `reports/` |
| `predict.py` | batch inference with input validation |
| `app.py` | Streamlit app: single prediction, CSV upload, results, model card |
| `tests/test_smoke.py` | automatic checks |

## 6 · Project write-up (replace this section)

- **Problem statement:** We want to predict … for … using … so that … can … . Success = … ; baseline = … .
- **Data:** source, rows, columns, missing values and how you handled them (and why), leakage risks you checked.
- **Split & metric:** method, seed, metric, and why.
- **Models compared:** table of CV results (from `reports/cv_results.csv`), and your choice with reasons.
- **Improvement experiment:** hypothesis → change → result (from `experiments.csv`).
- **Error analysis:** confusion matrix or residuals; which mistakes and why they matter.
- **Final test result** (opened once).
- **Limitations and responsible use:** see `MODEL_CARD.md`.
