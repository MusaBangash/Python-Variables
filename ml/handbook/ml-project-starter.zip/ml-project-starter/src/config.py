"""Load the project configuration (which dataset, which target, which metric)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_config(path=None):
    path = Path(path) if path else ROOT / "config.json"
    cfg = json.loads(path.read_text())
    required = ["data_path", "target", "task", "primary_metric"]
    missing = [k for k in required if k not in cfg]
    if missing:
        raise ValueError(f"config is missing: {missing}")
    if cfg["task"] not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    cfg.setdefault("id_cols", [])
    cfg.setdefault("drop_cols", [])
    cfg.setdefault("na_values", [])
    cfg.setdefault("sensitive_cols", [])
    cfg.setdefault("threshold", 0.5)
    cfg.setdefault("test_size", 0.2)
    cfg.setdefault("random_state", 42)
    return cfg
