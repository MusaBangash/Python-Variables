"""Candidate models. Every model is compared on the SAME split, folds and metric."""
from sklearn.dummy import DummyClassifier, DummyRegressor


def get_candidates(task, random_state=42):
    if task == "classification":
        return {
            "baseline": DummyClassifier(strategy="most_frequent"),
            # TODO (Session 2): add at least TWO real models, for example:
            # "logistic_regression": LogisticRegression(max_iter=2000),
            # "random_forest": RandomForestClassifier(n_estimators=300, random_state=random_state),
        }
    return {
        "baseline": DummyRegressor(strategy="mean"),
        # TODO (Session 2): add at least TWO real models, for example:
        # "linear_regression": LinearRegression(),
        # "random_forest": RandomForestRegressor(n_estimators=300, random_state=random_state),
    }


def get_search_spaces(task):
    """Hyperparameters to try with RandomizedSearchCV (python train.py --tune).

    Keys are model names from get_candidates. Parameter names start with 'model__'.
    TODO (Session 3): add a search space for your best model, for example:
        "random_forest": {"model__min_samples_leaf": [1, 5, 10, 20, 50],
                          "model__max_features": ["sqrt", 0.3, 0.5]},
    """
    return {}
