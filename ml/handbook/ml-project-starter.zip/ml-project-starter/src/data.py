"""Loading, splitting and input validation.

Rule 1 of this project: split BEFORE fitting any transformation (imputer, scaler, encoder).
All fitting happens inside the scikit-learn Pipeline, on training data only.
"""
import pandas as pd
from sklearn.model_selection import train_test_split

from src.config import ROOT


def read_raw(cfg, path=None):
    """Read a CSV the same way for training and for new data."""
    return pd.read_csv(path or ROOT / cfg["data_path"], na_values=cfg["na_values"] or None)


def load_xy(cfg):
    """Return features X and target y (0/1 for classification)."""
    df = read_raw(cfg)
    df = df.dropna(subset=[cfg["target"]])
    y = df[cfg["target"]]
    if cfg["task"] == "classification":
        y = (y == cfg["positive_label"]).astype(int)
    X = df.drop(columns=[cfg["target"]] + cfg["id_cols"] + cfg["drop_cols"], errors="ignore")
    return X, y


def split(X, y, cfg):
    """Train/test split with a fixed seed. Classification is stratified (same class balance in both)."""
    return train_test_split(
        X, y,
        test_size=cfg["test_size"],
        random_state=cfg["random_state"],
        stratify=y if cfg["task"] == "classification" else None,
    )


def column_types(X):
    numeric = X.select_dtypes(include="number").columns.tolist()
    categorical = [c for c in X.columns if c not in numeric]
    return numeric, categorical


def infer_schema(X):
    """Describe the columns the model expects. Saved next to the model and used to validate new rows."""
    numeric, categorical = column_types(X)
    schema = {}
    for c in numeric:
        s = X[c]
        schema[c] = {"type": "numeric", "min": float(s.min()), "max": float(s.max()),
                     "median": float(s.median()), "integer": bool((s.dropna() % 1 == 0).all())}
    for c in categorical:
        vals = X[c].dropna().astype(str)
        schema[c] = {"type": "categorical", "values": sorted(vals.unique().tolist()),
                     "mode": vals.mode().iloc[0] if len(vals) else None}
    return schema


def validate_input(df, schema):
    """Check new rows before predicting. Returns (errors, warnings).

    errors   -> we must NOT predict (missing columns, text in a numeric column)
    warnings -> we can predict, but a human should look (values outside the training range, unseen categories)
    """
    errors, warnings = [], []
    missing = [c for c in schema if c not in df.columns]
    if missing:
        errors.append(f"missing columns: {missing}")
    for c, spec in schema.items():
        if c not in df.columns:
            continue
        col = df[c]
        if spec["type"] == "numeric":
            as_num = pd.to_numeric(col, errors="coerce")
            bad = col.notna() & as_num.isna()
            if bad.any():
                errors.append(f"{c}: {int(bad.sum())} value(s) are not numbers, e.g. {col[bad].iloc[0]!r}")
            out = (as_num < spec["min"]) | (as_num > spec["max"])
            if out.any():
                warnings.append(f"{c}: {int(out.sum())} value(s) outside the training range "
                                f"[{spec['min']:g}, {spec['max']:g}]")
        else:
            unseen = set(col.dropna().astype(str)) - set(spec["values"])
            if unseen:
                warnings.append(f"{c}: unseen categories {sorted(unseen)[:5]} (treated as 'unknown')")
        if col.isna().any():
            warnings.append(f"{c}: {int(col.isna().sum())} missing value(s) (will be imputed)")
    return errors, warnings
