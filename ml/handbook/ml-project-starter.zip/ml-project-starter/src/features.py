"""Feature engineering and preprocessing.

Everything here runs INSIDE the saved pipeline, so training, batch prediction and the app
all transform data in exactly the same way.
"""
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def add_features(df):
    """Domain-informed features. Must work on ANY rows (training, test, a single app input).

    TODO (Session 3): add at least one feature you can defend with a hypothesis, e.g.
        df["charges_per_month"] = df["TotalCharges"] / df["tenure"].clip(lower=1)
    Write the hypothesis and the cross-validated result in your README.
    """
    df = df.copy()
    return df


def build_preprocessor(numeric, categorical):
    """Impute + scale numbers; impute + one-hot encode categories."""
    numeric_steps = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical_steps = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("num", numeric_steps, numeric),
        ("cat", categorical_steps, categorical),
    ])
