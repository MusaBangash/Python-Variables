"""Metrics, plots and a per-group (fairness) report."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, average_precision_score, confusion_matrix, f1_score,
                             mean_absolute_error, mean_squared_error, precision_score, r2_score,
                             recall_score, roc_auc_score, ConfusionMatrixDisplay)

# scikit-learn scorer names for cross-validation, and whether higher is better
CV_SCORING = {
    "classification": {"roc_auc": "roc_auc", "avg_precision": "average_precision", "f1": "f1",
                       "accuracy": "accuracy", "log_loss": "neg_log_loss"},
    "regression": {"rmse": "neg_root_mean_squared_error", "mae": "neg_mean_absolute_error", "r2": "r2"},
}
LOWER_IS_BETTER = {"rmse", "mae", "log_loss"}


def classification_metrics(y, proba, threshold=0.5):
    pred = (proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "roc_auc": roc_auc_score(y, proba), "avg_precision": average_precision_score(y, proba),
        "accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
        "recall": recall_score(y, pred), "f1": f1_score(y, pred), "threshold": threshold,
        "true_negatives": int(tn), "false_positives": int(fp), "false_negatives": int(fn), "true_positives": int(tp),
    }


def regression_metrics(y, pred):
    return {"rmse": float(np.sqrt(mean_squared_error(y, pred))), "mae": mean_absolute_error(y, pred),
            "r2": r2_score(y, pred)}


def save_plots(task, y, output, path_prefix, threshold=0.5):
    """Confusion matrix (classification) or predicted-vs-actual + residuals (regression)."""
    if task == "classification":
        ConfusionMatrixDisplay(confusion_matrix(y, (output >= threshold).astype(int)),
                               display_labels=["negative", "positive"]).plot(cmap="Blues", values_format="d")
        plt.title(f"Test set, threshold {threshold}")
    else:
        fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
        ax[0].scatter(y, output, s=8, alpha=.5); lim = [min(y.min(), output.min()), max(y.max(), output.max())]
        ax[0].plot(lim, lim, "k--"); ax[0].set_xlabel("actual"); ax[0].set_ylabel("predicted"); ax[0].set_title("Predicted vs actual")
        ax[1].scatter(output, y - output, s=8, alpha=.5); ax[1].axhline(0, color="k")
        ax[1].set_xlabel("predicted"); ax[1].set_ylabel("residual (actual - predicted)"); ax[1].set_title("Residuals")
    plt.tight_layout(); plt.savefig(f"{path_prefix}.png", dpi=110); plt.close("all")


def group_report(task, X, y, output, sensitive_cols, threshold=0.5):
    """The same metric, per group. Large gaps between groups need an explanation in the model card."""
    rows = []
    for col in sensitive_cols:
        if col not in X.columns:
            continue
        for value, idx in X.groupby(X[col].astype(str)).groups.items():
            yy, oo = y.loc[idx], pd.Series(output, index=X.index).loc[idx]
            row = {"column": col, "group": value, "n": len(idx)}
            if task == "classification":
                pred = (oo >= threshold).astype(int)
                row.update({"actual_positive_rate": yy.mean(), "predicted_positive_rate": pred.mean(),
                            "recall": recall_score(yy, pred, zero_division=0),
                            "precision": precision_score(yy, pred, zero_division=0)})
            else:
                row.update({"mean_actual": yy.mean(), "mean_predicted": oo.mean(),
                            "mae": mean_absolute_error(yy, oo)})
            rows.append(row)
    return pd.DataFrame(rows)
