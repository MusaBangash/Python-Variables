# Project brief: end-to-end tabular ML baseline

**User story:** As a business owner, I want a working, documented model that predicts <target> from <data>, with a simple app, so that my team can use it and trust its limits.

## Acceptance criteria (all required)
1. Clear problem statement, target and metric, with a reason for the metric.
2. Leakage-aware split (split before fitting any transformation; seed recorded).
3. Preprocessing in a scikit-learn pipeline.
4. A baseline **plus at least two** candidate models, compared with cross-validation on the same folds.
5. Appropriate metrics; test set used once.
6. Brief error analysis (confusion matrix or residuals) explained in context.
7. Saved pipeline that predicts on unseen rows from a fresh session (`predict.py`, tests pass).
8. Streamlit app showing a prediction and the results.
9. README (write-up) and MODEL_CARD.md completed.
10. Code, outputs and history in a GitHub repository.

**Stretch (optional):** FastAPI endpoint · tuning with `--tune` · clustering comparison.

## Rubric
| Area | Weight |
|---|---|
| Problem framing and data handling | 20% |
| Pipeline and reproducibility | 20% |
| Evaluation and error analysis | 20% |
| App integration and usability | 15% |
| Code and documentation | 10% |
| Responsible-use discussion and demo | 15% |
