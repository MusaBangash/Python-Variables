# Model card: <your model name>

## Intended use
- What decision does this model support, and who uses it?
- **Not intended for:** …

## Data
- Source and period:
- Rows / columns used; target definition:
- Cleaning: missing values (how and why), duplicates, dropped columns:

## Model
- Type and key settings:
- Threshold (classification) and why:
- Compared against (baseline and other candidates):

## Evaluation (test set, opened once)
| Metric | Baseline | Final model |
|---|---|---|
| … | … | … |

## Fairness (from reports/fairness.csv)
- Metric per group for each sensitive column; any gaps and your interpretation:

## Limitations
- Where it fails / was not tested:
- Associations, not causes:

## Risks and responsible use
- Privacy and data handling:
- What harm could false positives / false negatives cause?
- Monitoring plan (drift, retraining):

## Reproducibility
- random_state, library versions (reports/metrics.json), git commit, date:
