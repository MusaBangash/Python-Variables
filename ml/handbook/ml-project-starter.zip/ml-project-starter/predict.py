"""Batch inference on new rows.

    python predict.py --input reports/new_rows_example.csv --output reports/predictions.csv
"""
import argparse
import json
import sys

import joblib
import sklearn

from src.config import ROOT, load_config
from src.data import read_raw, validate_input


def load_artifacts():
    model = joblib.load(ROOT / "models/model.joblib")
    schema = json.loads((ROOT / "models/schema.json").read_text())
    meta = json.loads((ROOT / "reports/metrics.json").read_text())
    if meta["sklearn_version"] != sklearn.__version__:
        print(f"WARNING: model trained with scikit-learn {meta['sklearn_version']}, running {sklearn.__version__}. "
              "Retrain or install the same version.", file=sys.stderr)
    return model, schema, meta


def predict_frame(model, schema, meta, df):
    X = df[[c for c in schema]]
    out = df.copy()
    if meta["task"] == "classification":
        out["probability"] = model.predict_proba(X)[:, 1].round(4)
        out["prediction"] = (out["probability"] >= meta["threshold"]).astype(int)
    else:
        out["prediction"] = model.predict(X).round(2)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default=str(ROOT / "reports/predictions.csv"))
    args = parser.parse_args()

    cfg = load_config()
    model, schema, meta = load_artifacts()
    df = read_raw(cfg, args.input)
    errors, warnings = validate_input(df, schema)
    for w in warnings:
        print("WARNING:", w)
    if errors:
        for e in errors:
            print("ERROR:", e)
        sys.exit("Input rejected: fix the errors above. No predictions were made.")
    out = predict_frame(model, schema, meta, df)
    out.to_csv(args.output, index=False)
    print(f"Wrote {len(out)} predictions to {args.output}")


if __name__ == "__main__":
    main()
