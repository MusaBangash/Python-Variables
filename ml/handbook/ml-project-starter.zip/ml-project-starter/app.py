"""Streamlit app: single prediction, batch prediction and model results.

    streamlit run app.py
"""
import json

import pandas as pd
import streamlit as st

from predict import load_artifacts, predict_frame
from src.config import ROOT, load_config
from src.data import validate_input

st.set_page_config(page_title="ML project", layout="wide")
cfg = load_config()

try:
    model, schema, meta = load_artifacts()
except FileNotFoundError:
    st.error("No trained model found. Run `python train.py` first.")
    st.stop()

st.title(cfg.get("name", "ML project"))
st.caption(f"Predicts **{cfg['target']}** · model: **{meta['best_model']}** · trained {meta['trained_at']}")

tab_one, tab_batch, tab_results, tab_card = st.tabs(["Single prediction", "Batch (CSV)", "Model results", "Model card"])

with tab_one:
    st.write("Fill in one record. Defaults are typical training values.")
    values = {}
    cols = st.columns(3)
    for i, (name, spec) in enumerate(schema.items()):
        with cols[i % 3]:
            if spec["type"] == "numeric":
                step = 1.0 if spec["integer"] else 0.1
                values[name] = st.number_input(name, value=float(spec["median"]), step=step)
            else:
                options = spec["values"]
                values[name] = st.selectbox(name, options, index=options.index(spec["mode"]) if spec["mode"] in options else 0)
    if st.button("Predict", type="primary"):
        row = pd.DataFrame([values])
        errors, warnings = validate_input(row, schema)
        for w in warnings:
            st.warning(w)
        if errors:
            st.error("; ".join(errors))
        else:
            result = predict_frame(model, schema, meta, row).iloc[0]
            if meta["task"] == "classification":
                st.metric("Probability of positive class", f"{result['probability']:.1%}")
                st.write(f"Decision at threshold {meta['threshold']}: **{'positive' if result['prediction'] else 'negative'}**")
            else:
                st.metric(f"Predicted {cfg['target']}", f"{result['prediction']:,.2f}")
            # TODO (project): explain the prediction (top factors) in plain words for the user

with tab_batch:
    file = st.file_uploader("Upload a CSV with the same columns as the training data", type="csv")
    if file is not None:
        df = pd.read_csv(file, na_values=cfg["na_values"] or None)
        errors, warnings = validate_input(df, schema)
        for w in warnings:
            st.warning(w)
        if errors:
            st.error("Input rejected: " + "; ".join(errors))
        else:
            out = predict_frame(model, schema, meta, df)
            st.dataframe(out, width='stretch')
            st.download_button("Download predictions", out.to_csv(index=False), "predictions.csv")

with tab_results:
    st.subheader("Cross-validation (training data, 5 folds)")
    st.dataframe(pd.read_csv(ROOT / "reports/cv_results.csv").round(4), width='stretch')
    st.subheader("Final test (opened once)")
    st.json(meta["test"])
    st.image(str(ROOT / "reports/test_plot.png"))
    fairness = ROOT / "reports/fairness.csv"
    if fairness.exists() and fairness.stat().st_size > 5:
        st.subheader("Metrics per group")
        st.dataframe(pd.read_csv(fairness).round(3), width='stretch')

with tab_card:
    card = ROOT / "MODEL_CARD.md"
    st.markdown(card.read_text() if card.exists() else "Write MODEL_CARD.md")
