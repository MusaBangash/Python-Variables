"""Train, compare and save a model.

    python train.py                 # compare all candidates with 5-fold CV, test the best once, save it
    python train.py --tune          # also run RandomizedSearchCV on models listed in get_search_spaces()
    python train.py --config datasets/medical_charges/config.json

Outputs:
    models/model.joblib       the complete pipeline (features + preprocessing + model)
    models/schema.json        the columns and value ranges the model expects
    reports/metrics.json      cross-validation + final test metrics
    reports/cv_results.csv    every candidate, same folds, same metrics
    reports/test_plot.png     confusion matrix or residual plots
    reports/fairness.csv      metrics per group for the sensitive columns
    reports/new_rows_example.csv   unseen rows (no target) to try predict.py
    experiments.csv           one line per run: what was tried and what it scored
"""
import argparse
import json
import platform
import subprocess
import time

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import KFold, RandomizedSearchCV, StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer

from src.config import ROOT, load_config
from src.data import column_types, infer_schema, load_xy, split
from src.evaluate import (CV_SCORING, LOWER_IS_BETTER, classification_metrics, group_report,
                          regression_metrics, save_plots)
from src.features import add_features, build_preprocessor
from src.models import get_candidates, get_search_spaces


def make_pipeline(model, numeric, categorical):
    return Pipeline([
        ("features", FunctionTransformer(add_features)),
        ("preprocess", build_preprocessor(numeric, categorical)),
        ("model", model),
    ])


def git_commit():
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "no-git"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--tune", action="store_true")
    args = parser.parse_args()

    cfg = load_config(args.config)
    task, seed, primary = cfg["task"], cfg["random_state"], cfg["primary_metric"]
    np.random.seed(seed)
    (ROOT / "models").mkdir(exist_ok=True); (ROOT / "reports").mkdir(exist_ok=True)

    # 1. data and split (before any fitting)
    X, y = load_xy(cfg)
    X_train, X_test, y_train, y_test = split(X, y, cfg)
    print(f"{cfg.get('name', cfg['data_path'])}: {len(X_train)} train / {len(X_test)} test rows, task = {task}")
    numeric, categorical = column_types(add_features(X_train.head(50)))

    # 2. compare candidates with cross-validation on the training set only
    folds = (StratifiedKFold if task == "classification" else KFold)(n_splits=5, shuffle=True, random_state=seed)
    scoring = CV_SCORING[task]
    rows, fitted = [], {}
    spaces = get_search_spaces(task) if args.tune else {}
    for name, model in get_candidates(task, seed).items():
        pipe = make_pipeline(model, numeric, categorical)
        if name in spaces:
            search = RandomizedSearchCV(pipe, spaces[name], n_iter=15, cv=folds, random_state=seed,
                                        scoring=scoring[primary], n_jobs=-1).fit(X_train, y_train)
            pipe = search.best_estimator_
            print(f"  tuned {name}: {search.best_params_}")
        cv = cross_validate(pipe, X_train, y_train, cv=folds, scoring=scoring, n_jobs=-1)
        row = {"model": name}
        for metric in scoring:
            vals = cv[f"test_{metric}"] * (-1 if scoring[metric].startswith("neg_") else 1)
            row[metric] = vals.mean(); row[f"{metric}_std"] = vals.std()
        rows.append(row); fitted[name] = pipe
        print(f"  {name:28s} CV {primary} = {row[primary]:.4f} ± {row[primary + '_std']:.4f}")

    cv_table = pd.DataFrame(rows).sort_values(primary, ascending=primary in LOWER_IS_BETTER)
    cv_table.to_csv(ROOT / "reports/cv_results.csv", index=False)
    best_name = cv_table.iloc[0]["model"]
    print(f"Best by CV {primary}: {best_name}")

    # 3. fit the winner on all training data, open the test set ONCE
    best = fitted[best_name].fit(X_train, y_train)
    if task == "classification":
        output = best.predict_proba(X_test)[:, 1]
        test_metrics = classification_metrics(y_test, output, cfg["threshold"])
    else:
        output = best.predict(X_test)
        test_metrics = regression_metrics(y_test, output)
    save_plots(task, y_test, output, ROOT / "reports/test_plot", cfg["threshold"])
    group_report(task, X_test, y_test, output, cfg["sensitive_cols"], cfg["threshold"]).to_csv(
        ROOT / "reports/fairness.csv", index=False)

    # 4. save everything needed to reproduce and to serve
    joblib.dump(best, ROOT / "models/model.joblib")
    (ROOT / "models/schema.json").write_text(json.dumps(infer_schema(X_train), indent=2))
    X_test.drop(columns=[], errors="ignore").head(20).to_csv(ROOT / "reports/new_rows_example.csv", index=False)
    meta = {"dataset": cfg.get("name"), "task": task, "target": cfg["target"], "best_model": best_name,
            "primary_metric": primary, "cv": cv_table.to_dict(orient="records"),
            "test": {k: float(v) for k, v in test_metrics.items()},
            "threshold": cfg["threshold"], "random_state": seed, "train_rows": len(X_train), "test_rows": len(X_test),
            "sklearn_version": sklearn.__version__, "python": platform.python_version(),
            "git_commit": git_commit(), "trained_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    (ROOT / "reports/metrics.json").write_text(json.dumps(meta, indent=2, default=float))

    log = pd.DataFrame([{"time": meta["trained_at"], "commit": meta["git_commit"], "dataset": cfg.get("name"),
                         "best_model": best_name, f"cv_{primary}": cv_table.iloc[0][primary],
                         f"test_{primary}": test_metrics.get(primary), "tuned": args.tune, "seed": seed}])
    log_path = ROOT / "experiments.csv"
    log.to_csv(log_path, mode="a", header=not log_path.exists(), index=False)

    print("TEST (opened once):", {k: round(float(v), 4) for k, v in test_metrics.items()})
    print("Saved models/model.joblib, models/schema.json and reports/. Next: python predict.py --input reports/new_rows_example.csv")


if __name__ == "__main__":
    main()
