"""Run with:  pytest -q   (after python train.py)"""
import json

import pandas as pd

from predict import load_artifacts, predict_frame
from src.config import ROOT, load_config
from src.data import read_raw, validate_input


def test_saved_pipeline_predicts_on_unseen_rows():
    model, schema, meta = load_artifacts()
    rows = read_raw(load_config(), ROOT / "reports/new_rows_example.csv")
    out = predict_frame(model, schema, meta, rows)
    assert len(out) == len(rows)
    assert out["prediction"].notna().all()


def test_validation_rejects_missing_column():
    schema = json.loads((ROOT / "models/schema.json").read_text())
    first = next(iter(schema))
    rows = pd.read_csv(ROOT / "reports/new_rows_example.csv").drop(columns=[first])
    errors, _ = validate_input(rows, schema)
    assert errors, "a missing column must be an error"


def test_validation_rejects_text_in_numeric_column():
    schema = json.loads((ROOT / "models/schema.json").read_text())
    numeric = [c for c, s in schema.items() if s["type"] == "numeric"]
    rows = pd.read_csv(ROOT / "reports/new_rows_example.csv")
    rows[numeric[0]] = rows[numeric[0]].astype(object)
    rows.loc[rows.index[0], numeric[0]] = "abc"
    errors, _ = validate_input(rows, schema)
    assert errors
